# Download Link Manager Pro

WordPress Plugin quản lý link tải về với trang đếm ngược và hệ thống quảng cáo.

## Tính năng

- ✅ Quản lý link tải về
- ✅ Trang đếm ngược tùy chỉnh
- ✅ Hệ thống quảng cáo 6 vị trí
- ✅ Thống kê lượt tải
- ✅ Tự động cập nhật

## Cài đặt

1. Download plugin
2. Upload lên `/wp-content/plugins/`
3. Kích hoạt trong WordPress Admin

## Yêu cầu

- WordPress 5.0+
- PHP 7.0+

## Changelog

Xem file CHANGELOG.md